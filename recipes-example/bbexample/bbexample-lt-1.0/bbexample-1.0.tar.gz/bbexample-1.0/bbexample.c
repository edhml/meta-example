#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <unistd.h>

#include "bbexample.h"

int main(int argc, char *argv[])
{
  printf("Hello Yocto World...\n");

  LibHelloWorld();

  return 0;
}





